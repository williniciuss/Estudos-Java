class MultiplosDeTresAteCem {
	public static void main(String[] args) {
		for (int i = 3; i < 100; i += 3) {
			System.out.println(i);
		}
	}
}